﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace HW3_2
{
    class Program
    {
        static void Main(string[] args)
        {
            string filename = @"C:\Users\하선호\Desktop";

            StreamReader sR = new StreamReader(filename, Encoding.Default);

            string line;

            char[] splitchar = new char[1] {' '};
            int index = 0;

            while ((line = sR.ReadLine()) != null)
            {
                if(index == 0)
                {
                    index=+5;
                    continue;
                }
                string[] result = line.Split(splitchar, StringSplitOptions.RemoveEmptyEntries);
                DepartmentInfo Ainfo = new DepartmentInfo(int.Parse(result[0]), result[1], int.Parse(result[2]), int.Parse(result[3]),int.Parse(result[4]));

                int MathSum = 0;
                sR.ReadLine();
                MathSum =+ int.Parse(result[3]);
                sR.ReadLine();
                MathSum = +int.Parse(result[3]);
                sR.ReadLine();
                MathSum = +int.Parse(result[3]);

                Console.WriteLine("수학점수의 평균: {0}", MathSum / result[3].Length);
            }

            sR.Close();
            Console.ReadKey();
        }
    }
}
