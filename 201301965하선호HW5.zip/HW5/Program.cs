﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW5
{
    class Program
    {
        static void Main(string[] args)
        {
            Profile[] aprofile =
            {
                new Profile(){Name="김철수",Math=50,Eng=40,Korean=100},
                new Profile(){Name="이영희",Math=48,Eng=25,Korean=75},
                new Profile(){Name="김영철",Math=58,Eng=48,Korean=47}
            };

            var profiles = from Profile in aprofile
                           where Profile.Math > 60
                           orderby Profile.Math
                           select Profile;

            foreach(var Profile in profiles)
            {
                Console.WriteLine("{0},{1}", Profile.Name, Profile.Math);
            }

            Console.ReadKey();
        }
    }
}
