﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW5
{
    class Profile
    {
        public string Name { get; set; }
        public int Math { get; set; }
        public int Eng { get; set; }
        public int Korean { get; set; }

        public Profile()
        {

        }
    }
}
