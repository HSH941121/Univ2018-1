﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeligateEx
{
    delegate int MyDelegate(int a, int b);
    delegate double Dele_Diff(double a);
    delegate double Dele_Integ(double a);
    class Program
    {
        //더하기 함수
        static public int Plus(int a, int b)
        {
            return a + b;
        }
        // 빼기 함수
        static public int Minus(int a, int b)
        {
            return a - b;
        }

        //적분 함수
        public static double Integ(Dele_Integ aFun, double at1,double at2)
        {
            double h = 1.0;
            double result = 0;
            for(int i = 0; i < 100; i++)
            {
                result =+ aFun(at1 + (h*i)) * h;
                at1 += 0.1;
                if (at1 == at2) i = 100;
            }
            return result;
                
        }

        //미분 함수
        public static double Diff(Dele_Diff aFun, double at)
        {
            double h = 1.0E-10;
            return (aFun(at + h) - aFun(at)) / h;
            
        }

        static void Main(string[] args)
        {
            
            
            Dele_Diff calculate2;
            MyDelegate calculate;
            Dele_Integ calculate3;

            
            calculate2 = new Dele_Diff(Math.Sin);
            calculate = new MyDelegate(Plus);
            calculate3 = new Dele_Integ(Math.Sin);


            Integ(calculate3, 1, 2);
            Diff(calculate2, 1);
            int sum = calculate(1, 3);

            
            


        }
    }
}
