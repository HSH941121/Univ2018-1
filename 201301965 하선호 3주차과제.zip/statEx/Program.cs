﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace statEx
{
    class Program
    {
        static void Main(string[] args)
        {
            double[] input = new double[5] {1.0,2.0,3.0,4.0,5.0};

            List<double> inputLIst = new List<double>(input);
            inputLIst.Add(10.0);
            inputLIst.RemoveAt(0);

            

            statistics statis = new statistics(input);
            statistics statis1 = new statistics(inputLIst);

            Console.WriteLine("합:{0}", statis.Sum());
            Console.WriteLine("평균:{0}", statis.Average());
            Console.WriteLine("표준편차:{0}", statis.Veriance());
            Console.WriteLine("최댓값:{0}", statis.Max());
            Console.WriteLine("최소값:{0}", statis.Min());
            Console.ReadKey();
        }
    }
}
