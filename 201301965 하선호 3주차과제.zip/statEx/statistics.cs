﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace statEx
{
    class statistics
    {
        double[] data;

        public statistics(double[] input)
        {
            data = input; //ref참조형
        }
        //생성자의 다양화
        public statistics(List<double> input)
        {
            data = input.ToArray(); 
        }

        public double Sum()
        {
            return data.Sum();
        }

        public double Average()
        {
            return Sum() / data.Length;   //Average();
        }

        //표준편차(분산) (Xn-E(X))*(Xn-E(X))

        public double Veriance()
        {
            double result = 0; //초기화
            double avg = Average();

            for(int i =0; i<data.Length; i++)
            {
                result += Math.Pow(data[i], 2.0);
            }
            /*
            for(int i = 0;i>data.Length; i++)
            {
                result += Math.Pow(data[i] - avg, 2.0);
            }
            */
            //return result/ data.Length;
            return (result - (avg * avg)) / data.Length;
        }

        public double Max()
        {
            double result;
            double temp = -9999999;
            for(int i = 0; i<data.Length; i++)
            {
                if(temp < data[i])
                {
                    temp = data[i];
                }
                else
                {

                }
            }
            result = temp;
        
            return result;
        }

        public double Min()
        {
            double result;
            double temp = 9999999;
            for (int i = 0; i < data.Length; i++)
            {
                if (temp > data[i])
                {
                    temp = data[i];
                }
                else
                {

                }
            }
            result = temp;

            return result;
        }

    }
}
