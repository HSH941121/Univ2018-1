﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Randumterm
{
    public partial class Form1 : Form
    {
        Random randNum = new Random();
        public int UnLuckyNo;
        Stopwatch myWatch;
        Timer StopWatchTimer;



        public Form1()
        {
            //UnLuckyNo = randNum.Next(1, 9);
            InitializeComponent();
            
        }
        private void StopWatchTimer_Tick(object sender, EventArgs e)
        {
            labelClock.Text = myWatch.Elapsed.ToString();
            if (myWatch.Elapsed.Minutes == 1)
            {
                myWatch.Stop();
                StopWatchTimer.Stop();
                btImg.Image = Properties.Resources.untitled2;
                MessageBox.Show("시간초과 게임오버!");
            }

        }

        private void btSet_Click(object sender, EventArgs e)
        {
            StopWatchTimer.Start();
            myWatch.Start();
            
            btImg.Image = Properties.Resources.untitled;
            UnLuckyNo = randNum.Next(1, 9);
            Random aRanNo = new Random();
            
            int[] LuckyNo = new int[9];
            for(int i = 0; i< 8; i++)
            {
                LuckyNo[i] = aRanNo.Next(1, 9);
                for(int j = 0; j<i; j++)
                {
                    if(LuckyNo[i] == LuckyNo[j])
                    {
                        i --;
                    }
                }
            }
            
            button1.Text = LuckyNo[0].ToString();
            button2.Text = LuckyNo[1].ToString();
            button3.Text = LuckyNo[2].ToString();
            button4.Text = LuckyNo[3].ToString();
            button5.Text = LuckyNo[4].ToString();
            button6.Text = LuckyNo[5].ToString();
            button7.Text = LuckyNo[6].ToString();
            button8.Text = LuckyNo[7].ToString();
            button9.Text = LuckyNo[8].ToString();

            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(button1.Text == UnLuckyNo.ToString())
            {
                btImg.Image = Properties.Resources.untitled2;
                myWatch.Stop();
                MessageBox.Show("UnLucky....");
                
            }
            else
            {
                MessageBox.Show("아무일도 일어나지 않았습니다.");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.StopWatchTimer = new Timer(this.components);
            StopWatchTimer.Interval = 100;
            this.StopWatchTimer.Tick += new System.EventHandler(this.StopWatchTimer_Tick);
            myWatch = new Stopwatch();

            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (button2.Text == UnLuckyNo.ToString())
            {
                btImg.Image = Properties.Resources.untitled2;
                myWatch.Stop();
                MessageBox.Show("UnLucky....");
                
            }
            else
            {
                MessageBox.Show("아무일도 일어나지 않았습니다.");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (button3.Text == UnLuckyNo.ToString())
            {
                btImg.Image = Properties.Resources.untitled2;
                myWatch.Stop();
                MessageBox.Show("UnLucky....");
                
            }
            else
            {
                MessageBox.Show("아무일도 일어나지 않았습니다.");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (button4.Text == UnLuckyNo.ToString())
            {
                btImg.Image = Properties.Resources.untitled2;
                myWatch.Stop();
                MessageBox.Show("UnLucky....");
                
            }
            else
            {
                MessageBox.Show("아무일도 일어나지 않았습니다.");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (button5.Text == UnLuckyNo.ToString())
            {
                btImg.Image = Properties.Resources.untitled2;
                myWatch.Stop();
                MessageBox.Show("UnLucky....");
                
            }
            else
            {
                MessageBox.Show("아무일도 일어나지 않았습니다.");
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (button6.Text == UnLuckyNo.ToString())
            {
                btImg.Image = Properties.Resources.untitled2;
                myWatch.Stop();
                MessageBox.Show("UnLucky....");
                
            }
            else
            {
                MessageBox.Show("아무일도 일어나지 않았습니다.");
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (button7.Text == UnLuckyNo.ToString())
            {
                btImg.Image = Properties.Resources.untitled2;
                myWatch.Stop();
                MessageBox.Show("UnLucky....");
                
            }
            else
            {
                MessageBox.Show("아무일도 일어나지 않았습니다.");
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (button8.Text == UnLuckyNo.ToString())
            {
                btImg.Image = Properties.Resources.untitled2;
                myWatch.Stop();
                MessageBox.Show("UnLucky....");
                
            }
            else
            {
                MessageBox.Show("아무일도 일어나지 않았습니다.");
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (button9.Text == UnLuckyNo.ToString())
            {
                btImg.Image = Properties.Resources.untitled2;
                myWatch.Stop();
                MessageBox.Show("UnLucky....");
                
            }
            else
            {
                MessageBox.Show("아무일도 일어나지 않았습니다.");
            }
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            
        }

        private void btReset_Click(object sender, EventArgs e)
        {
            
            myWatch.Reset();
        }
    }
}
