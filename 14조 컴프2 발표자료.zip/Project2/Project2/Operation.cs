﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project2
{
    
    class Operation
    {
        public Operation()
        {

        }

        public double[,] Sum(double[,] A, double[,] B)
        {
            double[,] Result = new double[2, 2];
            Result[0, 0] = A[0, 0] + B[0, 0];
            Result[0, 1] = A[0, 1] + B[0, 1];
            Result[1, 0] = A[1, 0] + B[1, 0];
            Result[1, 1] = A[1, 1] + B[1, 1];
            return Result;
        }

        public double[,] Minus(double[,] A, double[,] B)
        {
            double[,] Result = new double[2, 2];
            Result[0, 0] = A[0, 0] - B[0, 0];
            Result[0, 1] = A[0, 1] - B[0, 1];
            Result[1, 0] = A[1, 0] - B[1, 0];
            Result[1, 1] = A[1, 1] - B[1, 1];
            return Result;
        }

        public double[,] Multiply(double[,] A, double[,] B)
        {
            double[,] Result = new double[2, 2];
            Result[0, 0] = A[0, 0] * B[0, 0] + A[0, 1] * B[1, 0];
            Result[0, 1] = A[0, 0] * B[0, 1] + A[0, 1] * B[1, 1];
            Result[1, 0] = A[1, 0] * B[0, 0] + A[1, 1] * B[1, 0];
            Result[1, 1] = A[1, 0] * B[0, 1] + A[1, 1] * B[1, 1];
            return Result;
        }

        public double[,] Transpose(double[,] A)
        {
            double[,] Result = new double[2, 2];
            Result[0, 0] = A[0, 0];
            Result[0, 1] = A[1, 0];
            Result[1, 0] = A[0, 1];
            Result[1, 1] = A[1, 1];
            return Result;
        }

        public double det(double[,] A)
        {
            double detResult = 0.0;
            detResult = A[0, 0] * A[1, 1] - A[0, 1] * A[1, 0];
            return detResult;
        }

        public double[,] inverse(double[,] A)
        {
            double[,] Result = new double[2, 2];
            if (A.GetLength(0) == A.GetLength(1))
            {
                
                    Result[0, 0] = A[1, 1] / det(A);
                    Result[0, 1] = -A[0, 1] / det(A);
                    Result[1, 0] = -A[1, 0] / det(A);
                    Result[1, 1] = A[0, 1] / det(A);
                    return Result;
                
            }
            else
            {
                Console.WriteLine("정방행렬이 아니므로 역행렬이 존재하지 않습니다.");
                return null;
            }
        }


        public double[,] ConstantMultiply(double A, double[,] B)
        {
            double[,] Result = new double[2, 2];
            Result[0, 0] = B[0, 0] * A;
            Result[0, 1] = B[0, 1] * A;
            Result[1, 0] = B[1, 0] * A;
            Result[1, 1] = B[1, 1] * A;
            return Result;
        }


        public void symmetric(double[,] A)
        {
            double[,] Result = new double[2, 2];
            Result = Transpose(A);
            if(Result[0,0] == A[0,0] && Result[0, 1] == A[0, 1] && Result[1, 0] == A[1, 0] && Result[1, 1] == A[1, 1])
            {
                Console.WriteLine("대칭행렬입니다.");
            }
            else
            {
                Console.WriteLine("대칭행렬이아닙니다.");
            }
            
        }

        public void skew_symmetric(double[,] A)
        {
            double[,] Result1 = Transpose(A);
            double[,] Result2 = ConstantMultiply(-1, A);
            if(Result1[0,0].Equals(Result2[0,0]) && Result1[0, 1].Equals(Result2[0, 1]) && Result1[1, 0].Equals(Result2[1, 0]) && Result1[1, 1].Equals(Result2[1, 1]))
            {
                Console.WriteLine("반대칭행렬입니다.");
            }
            else
            {
                Console.WriteLine("반대칭행렬이아닙니다.");
            }
        }

        public void Orthogonal(double[,] A)
        {
            double[,] Result = new double[2, 2];
            double[,] Result2 = new double[2, 2];
            Result = Transpose(A);
            Result2 = inverse(A);
            if(Result[0, 0] == Result2[0, 0] && Result[0, 1] == Result2[0, 1] && Result[1, 0] == Result2[1, 0] && Result[1, 1] == Result2[1, 1])
            {
                Console.WriteLine("직교행렬입니다.");
            }
            else
            {
                Console.WriteLine("직교행렬이아닙니다.");
            }
        }

    }
}
