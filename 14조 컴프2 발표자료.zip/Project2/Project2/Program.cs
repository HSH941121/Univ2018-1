﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project2
{
    class Program
    {
        static void Main(string[] args)
        {
            
            double[,] Aarray22 = new double[2, 2];
            double[,] Barray22 = new double[2, 2];

            Operation OP = new Operation();

            Console.WriteLine("A행렬을 입력해주세요.");

            for(int i = 0; i < Aarray22.GetLength(0); i++)
            {
                for(int j = 0; j < Aarray22.GetLength(0); j++)
                {
                    Console.Write("a{0}{1}:", i+1, j+1);
                    Aarray22[i, j] = double.Parse(Console.ReadLine());
                    
                    
                }
            }

            Console.WriteLine("B행렬을 입력해주세요.");
            for (int i = 0; i < Barray22.GetLength(0); i++)
            {
                for (int j = 0; j < Barray22.GetLength(0); j++)
                {
                    Console.Write("b{0}{1}:", i + 1, j + 1);
                    Barray22[i, j] = double.Parse(Console.ReadLine());
                }
            }

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            

            double[,] SumResult = OP.Sum(Aarray22, Barray22);
            Console.Write("행렬A + 행렬B의 결과:");
            for(int i = 0; i < SumResult.GetLength(0); i++)
            {
                for(int j = 0; j < SumResult.GetLength(0); j++)
                {
                    Console.Write("{0} ", SumResult[i, j]);
                }
            }

            Console.WriteLine();

            double[,] MinusResult = OP.Minus(Aarray22, Barray22);
            Console.Write("행렬A - 행렬B의 결과:");
            for (int i = 0; i < MinusResult.GetLength(0); i++)
            {
                for (int j = 0; j < MinusResult.GetLength(0); j++)
                {
                    Console.Write("{0} ", MinusResult[i, j]);
                }
            }

            Console.WriteLine();

            double[,] MultiplyResult = OP.Multiply(Aarray22, Barray22);
            Console.Write("행렬A * 행렬B의 결과:");
            for (int i = 0; i < MultiplyResult.Length / 2; i++)
            {
                for (int j = 0; j < MultiplyResult.Length / 2; j++)
                {
                    Console.Write("{0} ", MultiplyResult[i, j]);
                }
            }

            Console.WriteLine();
            Console.Write("행렬A의 전치행렬:");
            double[,] TransPoseA = OP.Transpose(Aarray22);
            for (int i = 0; i < TransPoseA.Length / 2; i++)
            {
                for (int j = 0; j < TransPoseA.Length / 2; j++)
                {
                    Console.Write("{0} ", TransPoseA[i, j]);
                }
            }

            Console.WriteLine();
            Console.Write("행렬B의 전치행렬:");
            double[,] TransPoseB = OP.Transpose(Barray22);
            for (int i = 0; i < TransPoseB.Length / 2; i++)
            {
                for (int j = 0; j < TransPoseB.Length / 2; j++)
                {
                    Console.Write("{0} ", TransPoseB[i, j]);
                }
            }

            Console.WriteLine();
            Console.Write("행렬A의 행렬식:");
            double detA = OP.det(Aarray22);
            Console.WriteLine("{0}", detA);

            Console.Write("행렬B의 행렬식:");
            double detB = OP.det(Barray22);
            Console.WriteLine("{0}", detB);

            Console.Write("행렬A의 역행렬:");
            double[,] inverseA = OP.inverse(Aarray22);
            for(int i=0;i<inverseA.Length/2; i++)
            {
                for(int j=0; j< inverseA.Length/2; j++)
                {
                    Console.Write("{0} ,", inverseA[i, j]);
                }
            }

            Console.WriteLine();

            Console.Write("행렬B의 역행렬:");
            double[,] inverseB = OP.inverse(Barray22);
            for (int i = 0; i < inverseB.Length / 2; i++)
            {
                for (int j = 0; j < inverseB.Length / 2; j++)
                {
                    Console.Write("{0} ,", inverseB[i, j]);
                }
            }

            Console.WriteLine();
            Console.Write("A행렬은 ");
            OP.symmetric(Aarray22);
            Console.Write("A행렬은 ");
            OP.skew_symmetric(Aarray22);
            Console.Write("A행렬은 ");
            OP.Orthogonal(Aarray22);
            Console.WriteLine();
            Console.Write("B행렬은 ");
            OP.symmetric(Barray22);
            Console.Write("B행렬은 ");
            OP.skew_symmetric(Barray22);
            Console.Write("B행렬은 ");
            OP.Orthogonal(Barray22);

          

            

            Console.ReadKey();


        }
    }
}
